package com.pkbg.eurekaclient.Controller;

import com.pkbg.eurekaclient.Entity.Player;
import com.pkbg.eurekaclient.Entity.Room;
import com.pkbg.eurekaclient.Handler.MyHandler;
import com.pkbg.eurekaclient.Repository.PlayerRepository;
import com.pkbg.eurekaclient.Repository.RoomRepository;
import com.pkbg.eurekaclient.Service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.aggregation.ArrayOperators;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.socket.TextMessage;

import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/room")
public class RoomController {
    @Autowired
    public RoomRepository roomRepository;

    @Autowired
    PlayerRepository playerRepository;

    @Autowired
    public RoomService roomService;

    @Autowired
    public MyHandler myHandler;

    @RequestMapping("/roomtest/{roomnumber}/{hostname}/{playernumber}/{gamestatus}/{password}")
    @ResponseBody
    public String roomtest(@PathVariable("roomnumber") Integer roomnumber, @PathVariable("hostname") String hostname,
                           @PathVariable("playernumber")Integer playernumber,@PathVariable("gamestatus") Integer status,
                           @PathVariable("password") Integer password) {

        Room room = new Room();
        room.setGamestatus(status);
        room.setHostname(hostname);
        room.setPlayernumber(playernumber);
        room.setRoomnumber(roomnumber);
        room.setRoompassword(password);
        roomRepository.save(room);
        return "room ok";
    }


    @RequestMapping("/playertest/{playername}/{HP}/{playerstatus}/{longtitude}/{latitude}/{playerteam}/{weaponname}/{roomnumber}")
    @ResponseBody
    public String playertest(@PathVariable("playername") String playername, @PathVariable("HP") Integer HP,
                           @PathVariable("playerstatus")Integer playerstatus,@PathVariable("longtitude") double longtitude,
                           @PathVariable("latitude") double latitude, @PathVariable("playerteam") Integer playerteam,
                             @PathVariable("weaponname")String weaponname, @PathVariable("roomnumber") Integer roomnumber) {

        Player player=new Player();
        player.setHP(HP);
        player.setLatitude(latitude);
        player.setLongtitude(longtitude);
        player.setPlayername(playername);
        player.setPlayerstatus(playerstatus);
        player.setPlayerteam(playerteam);
        player.setWeaponname(weaponname);
        player.setRoomnumber(roomnumber);
        playerRepository.save(player);
        return "room ok";
    }

    @RequestMapping("/create")
    @ResponseBody
    public Integer create(@RequestBody Map<String,Object> map) throws IOException
    {
        String username =map.get("username").toString();
        String Result1 = roomService.create(username);
        if (!Result1.equals("Success!"))
            return 1;
        return 0;
    }

    @RequestMapping("/join")
    @ResponseBody
    public Integer join(@RequestBody Map<String,Object> map) throws IOException
    {
        String username =map.get("username").toString();
        String room = map.get("roomnumber").toString();
        String pass = map.get("password").toString();
        Integer roomnumber = Integer.valueOf(room);
        Integer password = Integer.valueOf(pass);
        String Result2 = roomService.join(roomnumber,username,password);
        if (!Result2.equals("Success!"))
            return 1;
        return 0;
    }

}
